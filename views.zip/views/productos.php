<?php require_once RUTA_APP."/views/inc/header.php";?>
<?php require_once RUTA_APP."/views/inc/navbar.php";?>
<div class="container mt-5 p-5">

        <div class="row" >
            <div class="col-md-12">
                <h4>Productos Nutricionales</h4>
                <hr>
            </div>
        </div>
        <div class="row" id="productos">

        </div>
</div>
<?php require_once RUTA_APP."/views/inc/footer.php" ?>
<script src="<?php echo RUTA_URL ?>/assets/alertifyjs/alertify.min.js"></script>
<script src="<?php echo RUTA_URL ?>/assets/js/catalogo.js"></script>