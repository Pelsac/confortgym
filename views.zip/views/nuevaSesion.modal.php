<div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Nueva sesion de entrenamiento</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form  id="form-sesion" method="POST">
            <div class="modal-body">
                <div class="form-group">
                <label for="">Fecha y hora de rutina</label>
                <input type="datetime-local" name="fecha" id="fecha" class="form-control">
                </div>

               
                
            </div>
            <div class="modal-footer">
             
              <button type="submit" class="btn btn-primary btn-block" >Aceptar</button>
            </div>
            </form>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>